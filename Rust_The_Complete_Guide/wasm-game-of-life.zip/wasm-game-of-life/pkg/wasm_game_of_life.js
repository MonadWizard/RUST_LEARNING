import * as wasm from "./wasm_game_of_life_bg.wasm";
export * from "./wasm_game_of_life_bg.js";